### [logseq](http://logseq.com)

#### Install using Git

Coming soon.

#### Install manually


##### Offline install:

- Copy the content of `custom.css` into `logseq/custom.css` in your notes repo if you want to have the theme available without internet connection.

##### Online install:

- Paste this line to your `logseq/custom.css` file:
  `@import url('https://raw.githack.com/dracula/logseq/master/custom.css');`

#### Activating theme

1. Open the side bar
2. Click on dark theme
3. Boom! It's working
