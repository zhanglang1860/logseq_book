-
  > **Fluid Mechanics and Its Applications** [002](bookxnotepro://opennote/?nb={7eeb44c3-6948-459b-a29c-63e46dbbc7ec}&book=c00a3c7aa02860194e44137ec79fb095&page=1&x=182&y=65&id=23)
-
- 本书讨论了[[湍流]]，[[沉降]]，[[多相流]]，[[超音速，亚音速]]以及[[建模]]等方面的内容
- 流体输运物质和力是可以相互转化的，因此流体输运理论是交叉学科的基石。**Fluids have the ability to transport matter and its properties as wellas to transmit force, therefore fluid mechanics is a subject that is particularly open tocross fertilization with other sciences and disciplines of engineering.** [003](bookxnotepro://opennote/?nb={7eeb44c3-6948-459b-a29c-63e46dbbc7ec}&book=c00a3c7aa02860194e44137ec79fb095&page=2&x=220&y=196&id=4)
-
-
-